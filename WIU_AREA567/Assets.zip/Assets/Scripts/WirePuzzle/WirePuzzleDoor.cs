using UnityEngine;

public class WirePuzzleDoor : MonoBehaviour,
    IInteractable
{
    [SerializeField]
    private GameObject puzzlePanel;

    private bool unlocked;

    public void Interact(
        GameObject interactor)
    {
        if (unlocked)
        {
            OpenDoor();
            return;
        }

        puzzlePanel.SetActive(true);
    }

    public void UnlockDoor()
    {
        unlocked = true;

        puzzlePanel.SetActive(false);

        OpenDoor();
    }

    private void OpenDoor()
    {
        Debug.Log("Door opened.");

        // animation / disable collider later
    }
}