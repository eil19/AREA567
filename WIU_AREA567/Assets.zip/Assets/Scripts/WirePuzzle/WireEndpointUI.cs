using UnityEngine;

public class WireEndpointUI : MonoBehaviour
{
    [SerializeField] private WireType wireType;

    public WireType WireType => wireType;
}
