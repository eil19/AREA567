using UnityEngine;
using UnityEngine.Events;

public class WirePuzzleController : MonoBehaviour
{
    [Header("Puzzle")]
    [SerializeField]
    private int totalConnections = 4;

    [Header("Events")]
    public UnityEvent OnPuzzleCompleted;

    private int completedConnections;
    private bool isCompleted;

    public void RegisterConnection()
    {
        if (isCompleted)
            return;

        completedConnections++;

        Debug.Log(
            "Wire connected: " +
            completedConnections +
            "/" +
            totalConnections
        );

        if (completedConnections >=
            totalConnections)
        {
            CompletePuzzle();
        }
    }

    private void CompletePuzzle()
    {
        isCompleted = true;

        Debug.Log(
            "Wire puzzle completed."
        );

        OnPuzzleCompleted?.Invoke();
    }
}