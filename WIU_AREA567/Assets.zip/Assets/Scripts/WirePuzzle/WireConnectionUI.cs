using UnityEngine;
using UnityEngine.EventSystems;

public class WireConnectionUI : MonoBehaviour,
    IBeginDragHandler,
    IDragHandler,
    IEndDragHandler
{
    [Header("References")]
    [SerializeField]
    private RectTransform wireImage;

    [SerializeField]
    private WireEndpointUI startEndpoint;

    [SerializeField]
    private WirePuzzleController puzzleController;

    private bool isConnected;

    private void Start()
    {
        if (wireImage != null)
        {
            wireImage.gameObject.SetActive(false);
        }
    }

    public void OnBeginDrag(
        PointerEventData eventData)
    {
        if (isConnected)
            return;

        wireImage.gameObject.SetActive(true);

        UpdateWire(
            transform.position,
            eventData.position
        );
    }

    public void OnDrag(
        PointerEventData eventData)
    {
        if (isConnected)
            return;

        UpdateWire(
            transform.position,
            eventData.position
        );
    }

    public void OnEndDrag(
        PointerEventData eventData)
    {
        if (isConnected)
            return;

        GameObject target =
            eventData.pointerCurrentRaycast
                .gameObject;

        if (target == null)
        {
            ResetWire();
            return;
        }

        WireEndpointUI endEndpoint =
            target.GetComponent<
                WireEndpointUI>();

        if (endEndpoint == null)
        {
            ResetWire();
            return;
        }

        if (endEndpoint.WireType !=
            startEndpoint.WireType)
        {
            ResetWire();
            return;
        }

        ConnectTo(endEndpoint);
    }

    private void ConnectTo(
        WireEndpointUI endpoint)
    {
        isConnected = true;

        UpdateWire(
            transform.position,
            endpoint.transform.position
        );

        puzzleController
            .RegisterConnection();
    }

    private void ResetWire()
    {
        wireImage.gameObject.SetActive(false);
    }

    private void UpdateWire(
        Vector2 startPosition,
        Vector2 endPosition)
    {
        Vector2 direction =
            endPosition -
            startPosition;

        float distance =
            direction.magnitude;

        wireImage.position =
            startPosition;

        wireImage.sizeDelta =
            new Vector2(
                distance,
                wireImage.sizeDelta.y
            );

        float angle =
            Mathf.Atan2(
                direction.y,
                direction.x
            ) *
            Mathf.Rad2Deg;

        wireImage.rotation =
            Quaternion.Euler(
                0f,
                0f,
                angle
            );
    }
}